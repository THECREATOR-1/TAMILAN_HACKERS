// =============================================
// Maanvriksha – Pure Canvas Price Chart
// =============================================

let chartAnimFrame = null;

function renderPriceChart() {
    const canvas = document.getElementById('priceChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const data = marketData[currentCrop].history;

    // Cancel any ongoing animation
    if (chartAnimFrame) cancelAnimationFrame(chartAnimFrame);

    // Hi-DPI
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width - 48;
    const H = 200;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    ctx.scale(dpr, dpr);

    const pad = { top: 20, right: 20, bottom: 32, left: 44 };
    const chartW = W - pad.left - pad.right;
    const chartH = H - pad.top - pad.bottom;

    const minVal = Math.min(...data) * 0.95;
    const maxVal = Math.max(...data) * 1.05;

    function toX(i) { return pad.left + (i / (data.length - 1)) * chartW; }
    function toY(v) { return pad.top + chartH - ((v - minVal) / (maxVal - minVal)) * chartH; }

    const days = ['D-9', 'D-8', 'D-7', 'D-6', 'D-5', 'D-4', 'D-3', 'D-2', 'Yesterday', 'Today'];

    let progress = 0;
    const duration = 900;
    const startTime = performance.now();

    function draw(now) {
        const elapsed = now - startTime;
        progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);

        ctx.clearRect(0, 0, W, H);

        // Grid lines
        ctx.strokeStyle = 'rgba(107,200,78,0.08)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 4; i++) {
            const y = pad.top + (chartH / 4) * i;
            ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left + chartW, y); ctx.stroke();
            const val = maxVal - ((maxVal - minVal) / 4) * i;
            ctx.fillStyle = 'rgba(160,200,140,0.5)';
            ctx.font = '10px Outfit, sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText('₹' + Math.round(val), pad.left - 6, y + 4);
        }

        // X labels
        ctx.fillStyle = 'rgba(160,200,140,0.5)';
        ctx.font = '9px Outfit, sans-serif';
        ctx.textAlign = 'center';
        const step = Math.ceil(data.length / 5);
        for (let i = 0; i < data.length; i += step) {
            ctx.fillText(days[i], toX(i), H - 6);
        }
        ctx.fillText(days[data.length - 1], toX(data.length - 1), H - 6);

        // Gradient fill (clipped to progress)
        const clipX = pad.left + chartW * eased;
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 0, clipX, H);
        ctx.clip();

        // Area fill
        const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + chartH);
        grad.addColorStop(0, 'rgba(107,200,78,0.30)');
        grad.addColorStop(1, 'rgba(107,200,78,0.00)');
        ctx.beginPath();
        ctx.moveTo(toX(0), toY(data[0]));
        for (let i = 1; i < data.length; i++) {
            const cx = (toX(i - 1) + toX(i)) / 2;
            ctx.bezierCurveTo(cx, toY(data[i - 1]), cx, toY(data[i]), toX(i), toY(data[i]));
        }
        ctx.lineTo(toX(data.length - 1), pad.top + chartH);
        ctx.lineTo(toX(0), pad.top + chartH);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();

        // Line
        const lineGrad = ctx.createLinearGradient(pad.left, 0, pad.left + chartW, 0);
        lineGrad.addColorStop(0, '#6bc84e');
        lineGrad.addColorStop(1, '#c8f024');
        ctx.beginPath();
        ctx.moveTo(toX(0), toY(data[0]));
        for (let i = 1; i < data.length; i++) {
            const cx = (toX(i - 1) + toX(i)) / 2;
            ctx.bezierCurveTo(cx, toY(data[i - 1]), cx, toY(data[i]), toX(i), toY(data[i]));
        }
        ctx.strokeStyle = lineGrad;
        ctx.lineWidth = 2.5;
        ctx.lineJoin = 'round';
        ctx.stroke();

        // Dots
        for (let i = 0; i < data.length; i++) {
            if (toX(i) > clipX) break;
            ctx.beginPath();
            ctx.arc(toX(i), toY(data[i]), i === data.length - 1 ? 5 : 3.5, 0, Math.PI * 2);
            ctx.fillStyle = i === data.length - 1 ? '#c8f024' : '#6bc84e';
            ctx.fill();
            ctx.strokeStyle = '#0d1a07';
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }

        ctx.restore();

        if (progress < 1) chartAnimFrame = requestAnimationFrame(draw);
    }

    chartAnimFrame = requestAnimationFrame(draw);
}

// Init chart on load; re-render on resize
window.addEventListener('load', () => {
    setTimeout(renderPriceChart, 400);
});

let resizeTimer;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(renderPriceChart, 200);
});
