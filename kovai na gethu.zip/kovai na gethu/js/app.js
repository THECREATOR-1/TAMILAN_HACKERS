// =============================================
// Maanvriksha – Main Application Logic
// =============================================

// ---- Market Data ----
const marketData = {
    tomato: { name: '🍅 Tomato', current: 18, predicted: 26, trend: 'up', advice: '⏳ Wait before selling – price rising!', history: [15, 16, 17, 16, 18, 19, 18, 22, 24, 26] },
    onion: { name: '🧅 Onion', current: 22, predicted: 20, trend: 'down', advice: '⚡ Sell soon – slight price drop expected.', history: [20, 22, 24, 23, 22, 21, 22, 21, 20, 20] },
    groundnut: { name: '🥜 Groundnut', current: 58, predicted: 62, trend: 'up', advice: '⏳ Hold for 3–4 more days for better price.', history: [55, 56, 57, 56, 58, 59, 60, 61, 61, 62] },
    chilli: { name: '🌶️ Chilli', current: 110, predicted: 128, trend: 'up', advice: '🚀 Strong uptrend – hold if possible!', history: [90, 95, 100, 102, 108, 110, 115, 118, 122, 128] },
    rice: { name: '🌾 Rice', current: 32, predicted: 32, trend: 'neutral', advice: '→ Price stable. Sell when convenient.', history: [31, 32, 31, 32, 32, 32, 32, 33, 32, 32] }
};

const yieldData = {
    groundnut: { num: 2.8, soil: 76, weather: 82, crop: 70 },
    maize: { num: 4.5, soil: 80, weather: 88, crop: 74 },
    rice: { num: 3.2, soil: 72, weather: 75, crop: 81 },
    tomato: { num: 18.5, soil: 85, weather: 78, crop: 82 },
    cotton: { num: 1.8, soil: 68, weather: 71, crop: 65 },
    mango: { num: 12.0, soil: 88, weather: 90, crop: 85 },
    banana: { num: 35.0, soil: 82, weather: 75, crop: 90 }
};

let currentSoilData = {
    ph: 6.8,
    nitrogen: 'Medium',
    phosphorus: 'Medium',
    potassium: 'High',
    oc: 1.2,
    texture: 'Sandy Loam',
    score: 82
};

let currentWeather = {
    season: 'kharif',
    rainfall: 'medium',
    temp: 28,
    humidity: 60,
    description: 'clear sky'
};

let currentCrop = 'tomato';
let map; // price chart instance
let voiceOpen = false;
let micActive = false;
let recognition = null;

// ---- Navbar scroll effect ----
window.addEventListener('scroll', () => {
    const nav = document.getElementById('navbar');
    nav.style.background = window.scrollY > 50
        ? 'rgba(13,26,7,0.97)'
        : 'rgba(13,26,7,0.85)';
});

// ---- GPS Location ----
function detectLocation() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
        pos => {
            const { latitude, longitude } = pos.coords;
            fetchLocationName(latitude, longitude);
        },
        () => {
            document.getElementById('locationText').textContent = 'Tamil Nadu, India (default)';
            document.getElementById('soilLocationText').textContent = 'Tamil Nadu, India (GPS not available)';
        },
        { timeout: 8000 }
    );
}

async function fetchLocationName(lat, lon) {
    try {
        const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`);
        const d = await r.json();
        const city = d.address.city || d.address.town || d.address.village || d.address.county || 'Your Location';
        const state = d.address.state || '';
        const label = `${city}, ${state}`;
        document.getElementById('locationText').textContent = label;
        document.getElementById('soilLocationText').textContent = `📍 ${label} (${lat.toFixed(4)}, ${lon.toFixed(4)})`;

        // Trigger automated data fetching
        fetchSoilData(lat, lon);
        fetchWeatherData(lat, lon); // New real-time weather call
        fetchNasaAgriData(lat, lon); // New real-time agricultural data call
    } catch {
        document.getElementById('locationText').textContent = 'Location detected';
    }
}

// ---- Real-time Weather Integration (OpenWeatherMap) ----
async function fetchWeatherData(lat, lon) {
    try {
        const apiKey = CONFIG.OPENWEATHER_API_KEY;
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

        const response = await fetch(url);
        const data = await response.json();

        if (data && data.main) {
            currentWeather.temp = Math.round(data.main.temp);
            currentWeather.humidity = data.main.humidity;
            currentWeather.description = data.weather[0].description;
            currentWeather.rainfall_volume = data.rain ? (data.rain['1h'] || data.rain['3h'] || 0) : 0;

            // Map rainfall to categories
            if (currentWeather.rainfall_volume > 5) currentWeather.rainfall = 'high';
            else if (currentWeather.rainfall_volume > 0) currentWeather.rainfall = 'medium';
            else currentWeather.rainfall = 'low';

            console.log("Weather Data Synced:", data);
            updateWeatherUI();
            calculateSeasonAndRainfall(); // Refined with current month
        }
    } catch (err) {
        console.error("OpenWeather API Error:", err);
    }
}

function updateWeatherUI() {
    const tempVal = document.getElementById('tempVal');
    const descVal = document.getElementById('weatherDesc');
    const humidVal = document.getElementById('humidVal');

    if (tempVal) tempVal.textContent = `${currentWeather.temp}°C`;
    if (descVal) descVal.textContent = currentWeather.description.charAt(0).toUpperCase() + currentWeather.description.slice(1);
    if (humidVal) humidVal.textContent = `${currentWeather.humidity}%`;
}

// ---- SoilGrids API Integration ----
async function fetchSoilData(lat, lon) {
    try {
        // Using SoilGrids V2.0 REST API
        // Layers: phh2o (pH), nitrogen, phos (phosphorus), clay/sand (texture)
        const baseUrl = "https://rest.isric.org/soilgrids/v2.0/properties/query";
        const params = `?lon=${lon}&lat=${lat}&property=phh2o&property=nitrogen&property=soc&property=clay&property=sand&depth=0-5cm&value=mean`;

        const response = await fetch(baseUrl + params);
        const data = await response.json();

        if (data && data.properties && data.properties.layers) {
            const layers = data.properties.layers;
            const getVal = (id) => layers.find(l => l.name === id).depths[0].values.mean / 10;

            const ph = (getVal('phh2o') / 1).toFixed(1); // pH is scaled by 10 in API
            const nitrogen = getVal('nitrogen'); // mg/kg
            const soc = getVal('soc'); // g/kg
            const clay = getVal('clay');
            const sand = getVal('sand');

            // Map to human readable categories
            currentSoilData.ph = ph;
            currentSoilData.nitrogen = nitrogen > 150 ? 'High' : nitrogen > 80 ? 'Medium' : 'Low';
            currentSoilData.oc = (soc / 10).toFixed(1);

            // Texture Logic
            if (sand > 60) currentSoilData.texture = 'Sandy';
            else if (clay > 40) currentSoilData.texture = 'Clayey';
            else currentSoilData.texture = 'Loamy';

            // Simplified Score
            currentSoilData.score = Math.round(70 + (ph > 6 && ph < 7.5 ? 15 : 5) + (nitrogen > 100 ? 10 : 0));

            console.log("SoilGrids Data Synced:", currentSoilData);
            updateSoilUIDisplay();
        }
    } catch (err) {
        console.error("SoilGrids API Error, using fallback:", err);
    }
}

function updateSoilUIDisplay() {
    // This updates the hidden results so when user clicks "Check Soil" it's ready
    document.getElementById('soilScoreNum').textContent = currentSoilData.score;
    // Map text values to the result cards if needed (handled in checkSoil animation)
}

function calculateSeasonAndRainfall() {
    const month = new Date().getMonth(); // 0-11
    // Indian Seasons
    if (month >= 5 && month <= 9) {
        currentWeather.season = 'kharif';
        currentWeather.rainfall = 'high';
    } else if (month >= 10 || month <= 1) {
        currentWeather.season = 'rabi';
        currentWeather.rainfall = 'low';
    } else {
        currentWeather.season = 'zaid';
        currentWeather.rainfall = 'medium';
    }

    // Auto-update recommendation UI form
    const seasonSelect = document.getElementById('cropSeason');
    const rainfallSelect = document.getElementById('cropRainfall');
    const soilSelect = document.getElementById('cropSoilType');

    if (seasonSelect) seasonSelect.value = currentWeather.season;
    if (rainfallSelect) rainfallSelect.value = currentWeather.rainfall;
    if (soilSelect) soilSelect.value = currentSoilData.texture.toLowerCase();

    console.log("Weather/Season Predicted:", currentWeather);
}

// ---- Soil Check ----
function checkSoil() {
    const loading = document.getElementById('soilLoading');
    const results = document.getElementById('soilResults');
    const btn = document.getElementById('checkSoilBtn');

    btn.style.display = 'none';
    loading.style.display = 'flex';
    results.style.display = 'none';

    // Simulate API call delay (even if data is already fetched)
    setTimeout(() => {
        loading.style.display = 'none';
        results.style.display = 'block';
        btn.style.display = 'inline-flex';

        // Populate param cards with real data
        const params = document.querySelectorAll('.param-value');
        if (params.length >= 6) {
            params[0].textContent = currentSoilData.ph;
            params[1].textContent = currentSoilData.nitrogen;
            params[2].textContent = currentSoilData.phosphorus;
            params[3].textContent = currentSoilData.potassium;
            params[4].textContent = currentSoilData.oc + "%";
            params[5].textContent = currentSoilData.texture;
        }

        animateSoilScore(currentSoilData.score);
        results.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 2800);
}

function animateSoilScore(target) {
    const circle = document.getElementById('scoreCircle');
    const numEl = document.getElementById('soilScoreNum');
    const circumference = 408;
    let current = 0;
    const duration = 1200;
    const startTime = performance.now();

    const animate = (now) => {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        current = Math.round(target * eased);
        numEl.textContent = current;
        const offset = circumference - (circumference * current / 100);
        circle.setAttribute('stroke-dashoffset', offset);
        if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
}

// ---- Mobile Menu ----
function toggleMenu() {
    const menu = document.getElementById('mobileMenu');
    menu.classList.toggle('open');
}

// ---- Voice Assistant ----
function toggleVoiceAssistant() {
    voiceOpen = !voiceOpen;
    const modal = document.getElementById('voiceModal');
    const overlay = document.getElementById('voiceOverlay');
    modal.classList.toggle('open', voiceOpen);
    overlay.classList.toggle('show', voiceOpen);
    if (!voiceOpen && micActive) toggleMic();
}

function toggleMic() {
    micActive = !micActive;
    const btn = document.getElementById('micBtn');
    const icon = document.getElementById('micIcon');
    const status = document.getElementById('voiceStatus');
    const waves = document.getElementById('voiceWaves');

    btn.classList.toggle('listening', micActive);
    waves.classList.toggle('active', micActive);

    if (micActive) {
        icon.className = 'fas fa-stop';
        status.textContent = '🎙️ Listening...';
        startSpeechRecognition();
    } else {
        icon.className = 'fas fa-microphone';
        status.textContent = translations[currentLang].voice_listening || 'Listening…';
        if (recognition) recognition.stop();
    }
}

function startSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        showTranscript(null, 'Speech recognition not supported in this browser. Please use Chrome.');
        return;
    }
    recognition = new SpeechRecognition();
    recognition.lang = currentVoiceLang === 'ta' ? 'ta-IN' : currentVoiceLang === 'hi' ? 'hi-IN' : 'en-IN';
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.start();
    recognition.onresult = e => {
        const text = e.results[0][0].transcript;
        askQuestion(text);
        if (micActive) toggleMic();
    };
    recognition.onerror = () => {
        if (micActive) toggleMic();
        showTranscript(null, 'Could not hear you. Please try again.');
    };
}

async function askQuestion(question) {
    const lang = currentVoiceLang;
    showTranscript(question, "Thinking...");

    try {
        const answer = await generateAIResponse(question, lang);
        showTranscript(question, answer);
        speakResponse(answer, lang);
    } catch (err) {
        console.error("AI Error:", err);
        const errorMsg = err.message.length < 100 ? err.message : "Something went wrong with the AI connection.";
        showTranscript(question, `Sorry, I'm having trouble: ${errorMsg}. Please try again later.`);
    }
}

async function generateAIResponse(question, lang) {
    const apiKey = CONFIG.OPENAI_API_KEY;
    const url = "https://api.openai.com/v1/chat/completions";

    const context = `
        You are Maanvriksha, a smart farming AI advisor for Indian farmers.
        Current Soil Data: pH ${currentSoilData.ph || 6.8}, Nitrogen ${currentSoilData.nitrogen || 'Medium'}, OC ${currentSoilData.oc || 1.2}%, Texture ${currentSoilData.texture || 'Loamy'}.
        Current Weather: ${currentWeather.temp || 28}°C, ${currentWeather.description || 'Clear'}, Humidity ${currentWeather.humidity || 60}%.
        Response Language: ${lang === 'ta' ? 'Tamil' : lang === 'hi' ? 'Hindi' : 'English'}.
        Keep your answer helpful, practical for a farmer, and relatively concise (2-3 sentences).
        If the farmer asks about crops, fertilizer, or irrigation, use the data above.
    `;

    const body = {
        model: "gpt-4o-mini",
        messages: [
            { role: "system", content: context },
            { role: "user", content: question }
        ],
        temperature: 0.7
    };

    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify(body)
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("OpenAI API Error:", data);
            throw new Error(data.error?.message || `API Error: ${response.status}`);
        }

        return data.choices[0].message.content;
    } catch (err) {
        console.error("OpenAI Fetch Exception:", err);
        throw err;
    }
}

// "You asked" label per language
const youAskedLabel = { en: 'You asked', hi: 'आपने पूछा', ta: 'நீங்கள் கேட்டது' };

function showTranscript(question, answer) {
    const el = document.getElementById('voiceTranscript');
    const label = youAskedLabel[currentVoiceLang] || youAskedLabel.en;
    el.innerHTML = `
    ${question ? `<div style="color:var(--text-muted);font-size:0.82rem;margin-bottom:8px;">${label}: "${question}"</div>` : ''}
    <div style="color:var(--green-primary);font-weight:600;margin-bottom:6px;display:flex;align-items:center;gap:8px;"><i class="fas fa-robot"></i> Maanvriksha</div>
    <div style="line-height:1.6;">${answer}</div>
  `;
}

async function speakResponse(text, lang) {
    const apiKey = CONFIG.OPENAI_API_KEY;
    const url = "https://api.openai.com/v1/audio/speech";

    try {
        // Stop any existing speech
        if (window.speechSynthesis) window.speechSynthesis.cancel();

        // Map languages to specific voices or just use one for now
        // OpenAI TTS supports multiple voices: alloy, echo, fable, onyx, nova, shimmer
        const voice = lang === 'ta' ? 'nova' : lang === 'hi' ? 'shimmer' : 'alloy';

        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "tts-1",
                input: text,
                voice: voice
            })
        });

        if (!response.ok) throw new Error("OpenAI TTS failed");

        const blob = await response.blob();
        const audioUrl = URL.createObjectURL(blob);
        const audio = new Audio(audioUrl);
        audio.play();
    } catch (err) {
        console.error("OpenAI TTS Error:", err);
        // Fallback to browser synthesis
        if (!window.speechSynthesis) return;
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = lang === 'ta' ? 'ta-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';
        window.speechSynthesis.speak(utter);
    }
}

// ---- NASA Power API Integration ----
async function fetchNasaAgriData(lat, lon) {
    try {
        const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
        // Fetch last 7 days of solar and precip data
        const endDate = today;
        const lastWeek = new Date();
        lastWeek.setDate(lastWeek.getDate() - 7);
        const startDate = lastWeek.toISOString().split('T')[0].replace(/-/g, '');

        const url = `https://power.larc.nasa.gov/api/temporal/daily/point?parameters=ALLSKY_SFC_SW_DWN,PRECTOTCORR,WS2M&community=AG&longitude=${lon}&latitude=${lat}&start=${startDate}&end=${endDate}&format=JSON`;

        const response = await fetch(url);
        const data = await response.json();

        if (data && data.properties && data.properties.parameter) {
            const p = data.properties.parameter;
            // Calculate averages
            const avgSolar = Object.values(p.ALLSKY_SFC_SW_DWN).reduce((a, b) => a + b, 0) / 7;
            const totalPrecip = Object.values(p.PRECTOTCORR).reduce((a, b) => a + b, 0);

            console.log("NASA Power Data:", { avgSolar, totalPrecip });

            // Update Disease Risk based on humidity (from OpenWeather) and Precip
            updateDiseaseRisk(totalPrecip);
            updateIrrigationAdvice(totalPrecip);
        }
    } catch (err) {
        console.error("NASA Power Error:", err);
    }
}

function updateDiseaseRisk(weeklyPrecip) {
    const humid = currentWeather.humidity;
    const temp = currentWeather.temp;

    let risk = 'Low';
    if (humid > 80 && temp > 25) risk = 'High';
    else if (humid > 65 || weeklyPrecip > 20) risk = 'Medium';

    // Update UI (simplified)
    const alert1 = document.getElementById('alert1');
    if (alert1) {
        alert1.textContent = risk === 'High' ? "⚠️ High Fungal Risk detected due to humidity" : "✅ Low disease risk today";
        alert1.parentElement.className = `alert-item ${risk === 'High' ? 'danger' : 'success'}`;
    }
}

function updateIrrigationAdvice(weeklyPrecip) {
    const nextIrr = document.getElementById('nextIrrDate');
    if (weeklyPrecip > 15) {
        nextIrr.textContent = "Not needed (Recent Rain)";
    } else {
        nextIrr.textContent = "Tomorrow morning";
    }
}

// ---- Crop Recommendations ----
function getCropRecommendations() {
    const soil = document.getElementById('cropSoilType').value;
    const season = document.getElementById('cropSeason').value;
    const rainfall = document.getElementById('cropRainfall').value;
    const grid = document.getElementById('cropResults');

    grid.style.opacity = '0.4';
    grid.style.transition = 'opacity 0.3s';

    setTimeout(() => {
        grid.style.opacity = '1';
        // Dynamic recommendation based on inputs (simplified AI logic)
        const crops = getCropsByInputs(soil, season, rainfall);
        renderCropCards(crops);
    }, 600);
}

function getCropsByInputs(soil, season, rainfall) {
    const db = {
        kharif: {
            low: [
                { rank: '🥇', icon: 'fas fa-seedling', name: 'Groundnut', yield: '2.8 t/ha', water: 'Low', profit: '₹85,000/ha', match: 92 },
                { rank: '🥈', icon: 'fas fa-wheat-awn', name: 'Sesame', yield: '0.8 t/ha', water: 'Low', profit: '₹55,000/ha', match: 80 },
                { rank: '🥉', icon: 'fas fa-pepper-hot', name: 'Guava', yield: '15 t/ha', water: 'Low', profit: '₹1.1L/ha', match: 68 }
            ], medium: [
                { rank: '🥇', icon: 'fas fa-seedling', name: 'Brinjal (Eggplant)', yield: '25 t/ha', water: 'Med', profit: '₹1.2L/ha', match: 94 },
                { rank: '🥈', icon: 'fas fa-pepper-hot', name: 'Chilli', yield: '2 t/ha', water: 'Med', profit: '₹1.5L/ha', match: 88 },
                { rank: '🥉', icon: 'fas fa-apple-whole', name: 'Pomegranate', yield: '12 t/ha', water: 'Med', profit: '₹2.5L/ha', match: 75 }
            ], high: [
                { rank: '🥇', icon: 'fas fa-wheat-awn', name: 'Paddy (Rice)', yield: '5.2 t/ha', water: 'High', profit: '₹95,000/ha', match: 94 },
                { rank: '🥈', icon: 'fas fa-leaf', name: 'Banana', yield: '40 t/ha', water: 'High', profit: '₹3.2L/ha', match: 82 },
                { rank: '🥉', icon: 'fas fa-pepper-hot', name: 'Mango', yield: '10 t/ha', water: 'High', profit: '₹4.5L/ha', match: 70 }
            ]
        },
        rabi: {
            low: [
                { rank: '🥇', icon: 'fas fa-wheat-awn', name: 'Wheat', yield: '3.5 t/ha', water: 'Low', profit: '₹75,000/ha', match: 90 },
                { rank: '🥈', icon: 'fas fa-seedling', name: 'Chickpea', yield: '1.8 t/ha', water: 'Low', profit: '₹52,000/ha', match: 82 },
                { rank: '🥉', icon: 'fas fa-carrot', name: 'Mustard', yield: '1.5 t/ha', water: 'Low', profit: '₹42,000/ha', match: 71 }
            ], medium: [
                { rank: '🥇', icon: 'fas fa-carrot', name: 'Carrot', yield: '18 t/ha', water: 'Med', profit: '₹90,000/ha', match: 92 },
                { rank: '🥈', icon: 'fas fa-carrot', name: 'Potato', yield: '22 t/ha', water: 'Med', profit: '₹88,000/ha', match: 81 },
                { rank: '🥉', icon: 'fas fa-pepper-hot', name: 'Cabbage', yield: '30 t/ha', water: 'Med', profit: '₹1.1L/ha', match: 74 }
            ], high: [
                { rank: '🥇', icon: 'fas fa-carrot', name: 'Onion', yield: '20 t/ha', water: 'Med', profit: '₹80,000/ha', match: 88 },
                { rank: '🥈', icon: 'fas fa-leaf', name: 'Garlic', yield: '8 t/ha', water: 'Med', profit: '₹90,000/ha', match: 72 },
                { rank: '🥉', icon: 'fas fa-pepper-hot', name: 'Cauliflower', yield: '20 t/ha', water: 'Med', profit: '₹1.3L/ha', match: 65 }
            ]
        },
        zaid: {
            low: [
                { rank: '🥇', icon: 'fas fa-pepper-hot', name: 'Watermelon', yield: '18 t/ha', water: 'Low', profit: '₹72,000/ha', match: 85 },
                { rank: '🥈', icon: 'fas fa-seedling', name: 'Moong Dal', yield: '0.8 t/ha', water: 'Low', profit: '₹38,000/ha', match: 76 },
                { rank: '🥉', icon: 'fas fa-apple-whole', name: 'Lemon', yield: '20 t/ha', water: 'Low', profit: '₹1.8L/ha', match: 65 }
            ], medium: [
                { rank: '🥇', icon: 'fas fa-seedling', name: 'Bhindi (Okra)', yield: '8 t/ha', water: 'Med', profit: '₹56,000/ha', match: 78 },
                { rank: '🥈', icon: 'fas fa-carrot', name: 'Bitter Gourd', yield: '6 t/ha', water: 'Med', profit: '₹48,000/ha', match: 68 },
                { rank: '🥉', icon: 'fas fa-leaf', name: 'Papaya', yield: '60 t/ha', water: 'Med', profit: '₹2.8L/ha', match: 74 }
            ], high: [
                { rank: '🥇', icon: 'fas fa-leaf', name: 'Cucumber', yield: '15 t/ha', water: 'Med', profit: '₹62,000/ha', match: 83 },
                { rank: '🥈', icon: 'fas fa-carrot', name: 'Pumpkin', yield: '20 t/ha', water: 'Med', profit: '₹45,000/ha', match: 66 },
                { rank: '🥉', icon: 'fas fa-leaf', name: 'Spinach', yield: '12 t/ha', water: 'High', profit: '₹55,000/ha', match: 60 }
            ]
        }
    };
    return (db[season] && db[season][rainfall]) ? db[season][rainfall] : db.kharif.medium;
}

function renderCropCards(crops) {
    const grid = document.getElementById('cropResults');
    grid.innerHTML = crops.map((c, i) => `
    <div class="crop-card ${i === 0 ? 'featured' : ''}">
      <div class="crop-rank">${c.rank} #${i + 1}</div>
      <div class="crop-img"><i class="${c.icon}"></i></div>
      <div class="crop-info">
        <h3>${c.name}</h3>
        <div class="crop-metrics">
          <div class="crop-metric"><i class="fas fa-chart-line"></i> Yield: ${c.yield}</div>
          <div class="crop-metric"><i class="fas fa-droplet"></i> Water: ${c.water}</div>
          <div class="crop-metric"><i class="fas fa-rupee-sign"></i> Profit: ${c.profit}</div>
        </div>
        <div class="crop-match">
          <div class="match-bar" style="width:${c.match}%"></div>
          <span>${c.match}% Match</span>
        </div>
      </div>
    </div>
  `).join('');
}

// ---- Market Prices ----
function selectCrop(crop, btn) {
    currentCrop = crop;
    document.querySelectorAll('.market-tab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    updateMarketDisplay();
    renderPriceChart();
}

function updateMarketDisplay() {
    const d = marketData[currentCrop];
    document.getElementById('mCropName').textContent = d.name;
    document.getElementById('currentPrice').textContent = d.current;
    document.getElementById('predPrice').textContent = d.predicted;
    const arrowEl = document.getElementById('priceArrow');
    arrowEl.innerHTML = d.trend === 'up'
        ? '<i class="fas fa-arrow-trend-up up"></i>'
        : d.trend === 'down'
            ? '<i class="fas fa-arrow-trend-down" style="color:var(--red)"></i>'
            : '<i class="fas fa-arrows-left-right" style="color:var(--text-muted)"></i>';
    document.getElementById('marketAdvice').innerHTML = `<i class="fas fa-lightbulb"></i> ${d.advice}`;
}

// ---- Government Schemes ----
// ---- Smart Government Schemes Search ----
let schemeSearchTimeout;
function filterSchemes(query) {
    const cards = document.querySelectorAll('#schemesGrid .scheme-card');
    const q = query.toLowerCase().trim();
    const aiContainer = document.getElementById('aiSchemes');
    const loading = document.getElementById('schemeSearching');

    // Clear previous AI results if query is empty
    if (!q) {
        cards.forEach(c => c.style.display = '');
        aiContainer.style.display = 'none';
        loading.style.display = 'none';
        return;
    }

    // 1. Local Filtering (Instant)
    let localCount = 0;
    cards.forEach(c => {
        const text = (c.dataset.scheme + ' ' + c.textContent).toLowerCase();
        const isMatch = text.includes(q);
        c.style.display = isMatch ? '' : 'none';
        if (isMatch) localCount++;
    });

    // 2. Smart AI Enrichment (Debounced)
    clearTimeout(schemeSearchTimeout);
    schemeSearchTimeout = setTimeout(async () => {
        // Only trigger AI if query is substantial or local results are low
        if (q.length > 2) {
            fetchAISchemes(q, localCount);
        }
    }, 800);
}

async function fetchAISchemes(query, localCount) {
    const aiContainer = document.getElementById('aiSchemes');
    const loading = document.getElementById('schemeSearching');

    loading.style.display = 'block';

    try {
        const apiKey = CONFIG.OPENAI_API_KEY;
        const url = "https://api.openai.com/v1/chat/completions";

        const prompt = `
            The user is searching for Indian government agriculture schemes related to: "${query}".
            I currently show these local schemes: PM-KISAN, PM Fasal Bima, TN Micro-Irrigation, Kisan Credit Card, Soil Health Card, e-NAM.
            
            Find 3 DIFFERENT real related schemes from the Central or State governments of India.
            Return ONLY a JSON array of objects with this structure:
            [{"id":"unique_id", "title":"Scheme Name", "desc":"Short description", "benefit":"The main financial benefit", "tags":["Tag1", "Tag2"], "color":"linear-gradient(135deg,#hex,#hex)", "icon":"fa-icon-name"}]
        `;

        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [{ role: "user", content: prompt }],
                response_format: { type: "json_object" }
            })
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("OpenAI API Error:", data);
            throw new Error(data.error?.message || `API Error: ${response.status}`);
        }

        const result = JSON.parse(data.choices[0].message.content);

        // Handle different possible JSON structures (OpenAI might return {schemes: [...]})
        const schemes = Array.isArray(result) ? result : result.schemes || Object.values(result)[0];
        renderAISchemes(schemes);
    } catch (err) {
        console.error("OpenAI Scheme Search Error:", err);
    } finally {
        loading.style.display = 'none';
    }
}

function renderAISchemes(schemes) {
    const container = document.getElementById('aiSchemes');
    if (!schemes || schemes.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.innerHTML = `
        <div style="grid-column: 1 / -1; margin-bottom: 10px; font-weight: 600; color: var(--purple); display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-sparkles"></i> Related Schemes Found by AI
        </div>
        ${schemes.map(s => `
            <div class="scheme-card" style="border-color: rgba(139,92,246,0.3); background: rgba(139,92,246,0.05);">
                <div class="scheme-icon" style="background:${s.color || '#8b5cf6'}"><i class="fas ${s.icon || 'fa-landmark'}"></i></div>
                <div class="scheme-body">
                    <h3>${s.title}</h3>
                    <p>${s.desc}</p>
                    <div class="scheme-tags">${s.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
                    <div class="scheme-benefits"><i class="fas fa-gift"></i> <span>${s.benefit}</span></div>
                    <button class="btn-apply" onclick="askQuestion('Tell me about ${s.title} scheme')"><i class="fas fa-robot"></i> <span>Ask AI Details</span></button>
                </div>
            </div>
        `).join('')}
    `;
    container.style.display = 'grid';
    initAnimations(); // Re-trigger animations for new cards
}

const schemeDetails = {
    pmkisan: { title: 'PM-KISAN Samman Nidhi', color: '#f59e0b', icon: 'fa-hand-holding-rupee', benefit: '₹6,000/year (₹2,000 × 3 installments)', eligibility: 'All landholding farmer families with cultivable land', process: '1. Visit pmkisan.gov.in\n2. Click "Farmer Corner"\n3. Register with Aadhar\n4. Submit land documents\n5. Amount credited within 2 weeks', contact: 'PM-KISAN Helpline: 011-23381092' },
    fby: { title: 'PM Fasal Bima Yojana', color: '#10b981', icon: 'fa-shield-halved', benefit: 'Full crop value coverage. Premium: Kharif 2%, Rabi 1.5%', eligibility: 'All farmers growing notified crops', process: '1. Contact nearest bank/CSC before cutoff date\n2. Fill crop insurance form\n3. Pay premium\n4. Claim via online portal if crop damaged', contact: 'Helpline: 1800-200-7710' },
    tnirr: { title: 'TN Micro-Irrigation Scheme', color: '#3b82f6', icon: 'fa-droplet', benefit: '75% subsidy for drip/sprinkler for small & marginal farmers', eligibility: 'Farmers in Tamil Nadu with land registered in their name', process: '1. Visit nearest Agri district office\n2. Apply at tnagrisnet.tn.gov.in\n3. Get field inspection\n4. Purchase approved equipment\n5. Subsidy credited to bank account', contact: 'TN Agri Helpline: 044-2561 0340' },
    kcc: { title: 'Kisan Credit Card', color: '#8b5cf6', icon: 'fa-credit-card', benefit: 'Credit up to ₹3 lakh at 7% interest (4% with subsidy)', eligibility: 'All farmers, sharecroppers, and self-help groups', process: '1. Visit nearest bank branch\n2. Fill KCC application form\n3. Submit land documents + ID proof\n4. Card issued in 14 days', contact: 'Agricultural helpline: 1551' },
    shc: { title: 'Soil Health Card Scheme', color: '#f97316', icon: 'fa-vial', benefit: 'Free soil testing every 2 years with nutrient recommendations', eligibility: 'All farmers in India', process: '1. Contact nearest Krishi Vigyan Kendra\n2. Collect soil sample (from 8-10 spots)\n3. Submit to soil testing lab\n4. Receive digital health card with recommendations', contact: 'India Agri Portal: 1800-180-1551' },
    enam: { title: 'e-NAM Online Market Platform', color: '#ec4899', icon: 'fa-store', benefit: 'Better prices through pan-India online auction', eligibility: 'All registered farmers', process: '1. Register at enam.gov.in with Aadhar\n2. Link bank account\n3. List produce for auction\n4. Receive payment within 24 hours', contact: 'e-NAM Helpline: 1800-270-0224' }
};

function showSchemeDetail(id) {
    const s = schemeDetails[id];
    if (!s) return;
    const body = document.getElementById('schemeModalBody');
    body.innerHTML = `
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;">
      <div style="width:56px;height:56px;border-radius:14px;background:${s.color};display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:#fff;"><i class="fas ${s.icon}"></i></div>
      <h2 style="font-size:1.3rem;line-height:1.3;">${s.title}</h2>
    </div>
    <div style="display:flex;flex-direction:column;gap:16px;">
      <div style="padding:14px;background:rgba(107,200,78,0.08);border-radius:12px;border:1px solid rgba(107,200,78,0.2);">
        <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">💰 BENEFIT</div>
        <div style="font-weight:600;color:var(--green-primary);">${s.benefit}</div>
      </div>
      <div style="padding:14px;background:rgba(59,130,246,0.08);border-radius:12px;border:1px solid rgba(59,130,246,0.2);">
        <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px;">✅ ELIGIBILITY</div>
        <div style="font-size:0.9rem;">${s.eligibility}</div>
      </div>
      <div style="padding:14px;background:rgba(139,92,246,0.08);border-radius:12px;border:1px solid rgba(139,92,246,0.2);">
        <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:8px;">📋 HOW TO APPLY</div>
        <div style="font-size:0.85rem;line-height:1.8;white-space:pre-line;">${s.process}</div>
      </div>
      <div style="font-size:0.85rem;color:var(--text-muted);display:flex;align-items:center;gap:8px;"><i class="fas fa-phone" style="color:var(--green-primary)"></i>${s.contact}</div>
    </div>
  `;
    document.getElementById('schemeModal').classList.add('open');
    document.getElementById('modalOverlay').classList.add('show');
}

function closeSchemeModal() {
    document.getElementById('schemeModal').classList.remove('open');
    document.getElementById('modalOverlay').classList.remove('show');
}

// ---- Sustainability ----
function updateSustainability() {
    const sliders = document.querySelectorAll('.sustain-sliders input');
    const waterEff = 100 - (parseInt(sliders[0].value) * 0.5);
    const diversity = parseInt(sliders[1].value);
    const fertEff = 100 - (parseInt(sliders[2].value) * 0.4);
    const score = Math.round((waterEff * 0.35 + diversity * 0.35 + fertEff * 0.3));

    document.getElementById('sustainScore').textContent = score;
    const circle = document.getElementById('sustainCircle');
    const circumference = 314;
    const offset = circumference - (circumference * score / 100);
    circle.setAttribute('stroke-dashoffset', offset);
}

// ---- Yield Prediction ----
function updateYieldPrediction() {
    const crop = document.getElementById('yieldCropSelect').value;
    const d = yieldData[crop] || yieldData.groundnut;
    document.getElementById('yieldNum').textContent = d.num;
    const fills = document.querySelectorAll('.yield-result .factor-fill');
    const spans = document.querySelectorAll('.yield-result .factor span:last-child');
    if (fills[0]) { fills[0].style.width = `${d.soil}%`; if (spans[0]) spans[0].textContent = `${d.soil}%`; }
    if (fills[1]) { fills[1].style.width = `${d.weather}%`; if (spans[1]) spans[1].textContent = `${d.weather}%`; }
    if (fills[2]) { fills[2].style.width = `${d.crop}%`; if (spans[2]) spans[2].textContent = `${d.crop}%`; }
}

// ---- Scroll Animations ----
const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (e.isIntersecting) {
            e.target.style.opacity = '1';
            e.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.1 });

function initAnimations() {
    const animatable = document.querySelectorAll('.dash-card, .crop-card, .scheme-card, .param-card, .tip-card, .mkt-mini-card');
    animatable.forEach((el, i) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(24px)';
        el.style.transition = `opacity 0.5s ease ${i * 0.06}s, transform 0.5s ease ${i * 0.06}s`;
        observer.observe(el);
    });
}

// ---- Init ----
window.addEventListener('DOMContentLoaded', () => {
    detectLocation();
    updateMarketDisplay();
    initAnimations();
    setLanguage('en');
});
