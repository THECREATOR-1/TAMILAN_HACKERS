// Maanvriksha API Configuration
const CONFIG = {
    GEMINI_API_KEY: "AIzaSyCUj2RxLaXUi6dPSGQx96RlGyi-2ZqOWWI",
    OPENWEATHER_API_KEY: "badabfb2fc4d582d87d017a7c643c1fd",
    NASA_POWER_API_KEY: "XGZokpiHVmZDTdXOdcQRrUsVL3QfBjPrgxAVsm1t",
    SARVAM_API_KEY: "sk_sdn1g764_osds7krtRKVsIr4gN5QRzqmU",
    OPENAI_API_KEY: "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"
};
